Assignment 8 - Policy Evaluation
Daniel Campos, Samuel Fraley, Eric Gutierrez

HOW TO RUN:

1. Question 1.1 (Figure 1):
   - Run code.ipynb in Jupyter
   - Output: Figure saved as plot

2. Questions 1.2 & 1.3 (Employment and Price Effects):
   - Run combined_analysis.do in Stata
   - Outputs: Regression tables in console

DATA REQUIRED:
- assignment8.dta (Stata data file)